GramFi bot screenshots (English), 27 Oct 2026

How these were made: every screen is the bot's real text and buttons, produced by the actual bot code
(branch claude/staging) with Telegram and Polymarket replaced by local fakes, then drawn in a Telegram-style frame.
Telegram's own look (fonts, link previews, charts) is approximated.

Example data: the market 'Will BTC close above $90k on Friday?', its prices, the Discover traders
(sharp_sports, macro_mind, ... with 0x1111... style addresses), balances and the wallet address are made up.
Most screens are in DEMO mode; section 11 shows a real-money account. GramFi fee is set to 0%.


00  Onboarding
    00-onboarding-choice.png  Onboarding · demo or real
    00-onboarding-demo.png  Onboarding · demo chosen
    00-onboarding-language.png  Onboarding · after language
    00-onboarding-start.png  Onboarding · first /start

01  Main menu
    01-main.png  Main menu

02  Markets
    02-markets.png  Markets
    02-markets-categories.png  Markets · categories

03  Market card and betting
    03-market-alert.png  Market · price alert
    03-market-amount.png  Bet · choose amount
    03-market-card.png  Market card
    03-market-confirm.png  Bet · confirmation
    03-market-filled.png  Bet · filled, portfolio

04  Portfolio
    04-portfolio-alerts.png  Portfolio · alerts
    04-portfolio-history.png  Portfolio · history
    04-portfolio-open.png  Portfolio · open
    04-portfolio-position.png  Portfolio · position
    04-portfolio-stats.png  Portfolio · stats
    04-portfolio-watch.png  Portfolio · watchlist

05  Copy trading and Discover
    05-copy.png  Copy trading
    05-copy-add.png  Copy · add trader
    05-copy-discover.png  Discover top traders
    05-copy-discover-pnl.png  Discover · top by PnL
    05-copy-discover-winrate.png  Discover · top by win rate
    05-copy-my.png  Copy · my traders
    05-copy-stats.png  Copy · statistics

06  Autotrading
    06-autotrading.png  Autotrading
    06-autotrading-lab.png  Autotrading · new strategy

07  Perps
    07-perps.png  Perps
    07-perps-account.png  Perps · positions & account
    07-perps-assets.png  Perps · all assets
    07-perps-card.png  Perps · instrument card
    07-perps-confirm.png  Perps · open long
    07-perps-open.png  Perps · position opened

08  Wallet (demo)
    08-wallet-demo.png  Wallet (demo)

09  Settings
    09-settings.png  Settings
    09-settings-language.png  Settings · language
    09-settings-mode.png  Settings · demo / real
    09-settings-notifications.png  Settings · notifications
    09-settings-oneclick.png  Settings · one-click
    09-settings-referral.png  Settings · referral

10  Support
    10-support.png  Support

11  Real-money account: main menu, wallet, deposit
    11-deposit.png  Deposit
    11-main-live.png  Main menu (real money)
    11-wallet-live.png  Wallet (real money)
